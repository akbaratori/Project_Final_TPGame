﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class ScoreManager : MonoBehaviour
{
  public static ScoreManager instance;
  public TextMeshProUGUI text;
  int score = 100;
  public int delayAmount = 1;
  private float Timer;
    // Start is called before the first frame update
    void Start()
    {
      if(instance == null){
        instance = this;
      }
    }

    public void changeScore(int foodValue){
      score += foodValue;
      text.text = "HP : "+score.ToString();
    }
    void Update(){
      Timer += Time.deltaTime;
      if (Timer >= delayAmount)
      {
        Timer = 0f;
        score--;
        text.text = "HP : "+score.ToString();
      }
      if (score > 100){score = 100;}
      if (score == 0){SceneManager.LoadScene("SampleScene");}
    }

}
